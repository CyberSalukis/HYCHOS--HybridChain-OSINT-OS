"""JSON Schemas package."""
